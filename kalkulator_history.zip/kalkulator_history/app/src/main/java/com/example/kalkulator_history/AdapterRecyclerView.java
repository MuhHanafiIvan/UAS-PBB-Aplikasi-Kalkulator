package com.example.kalkulator_history;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;

public class AdapterRecyclerView extends RecyclerView.Adapter<AdapterRecyclerView.ViewHolder> {
    private String[] SubjectValues;
    private Context context;

    AdapterRecyclerView(Context context1, String[] SubjectValues1) {
        SubjectValues = SubjectValues1;
        context = context1;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        ViewHolder(View v) {
            super(v);
            textView = v.findViewById(R.id.textItem);
        }
    }

    @NonNull
    @Override
    public AdapterRecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.list_item, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.textView.setText(SubjectValues[position]);
        String clickedvalue = SubjectValues[position];


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Snackbar.make(v, clickedvalue, Snackbar.LENGTH_SHORT).show();
                SharedPreferences sharedPreferences;
                sharedPreferences = v.getContext().getSharedPreferences("history", 0);

                String hasil_history = sharedPreferences.getString("history", null);
                hasil_history = hasil_history.substring(1,hasil_history.length()-1);
                String[] list_history = hasil_history.split(",");

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("history", String.valueOf(list_history));
                editor.apply();
            }
        });
    }

    @Override
    public int getItemCount() {
        return SubjectValues.length;
    }
}