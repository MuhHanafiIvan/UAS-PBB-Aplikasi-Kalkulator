package com.example.kalkulator_history;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    EditText txtNum1, txtNum2;
    Button btnHitung;
    TextView txtHasil;
    RadioButton rbTambah, rbKurang, rbKali, rbBagi;
    SharedPreferences sharedPreferences;
    List<String> list_history = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Kalkulator Bagus");

        btnHitung = findViewById(R.id.btnHitung);
        txtNum1 = findViewById(R.id.txtNum1);
        txtNum2 = findViewById(R.id.txtNum2);
        txtHasil = findViewById(R.id.txtHasil);
        rbTambah = findViewById(R.id.rbTambah);
        rbKurang = findViewById(R.id.rbKurang);
        rbKali = findViewById(R.id.rbKali);
        rbBagi = findViewById(R.id.rbBagi);

        sharedPreferences = getSharedPreferences("history", MODE_PRIVATE);
        sharedPreferences.contains("history");

        btnHitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double num1 = Double.parseDouble(txtNum1.getText().toString());
                double num2 = Double.parseDouble(txtNum2.getText().toString());
                double hasil = 0;
                String hishasil = null;
                SharedPreferences.Editor editor = sharedPreferences.edit();
                if (rbTambah.isChecked()) {
                    hasil = num1 + num2;
                    hishasil = String.valueOf(num1) + " + " + String.valueOf(num2) + " = " + String.valueOf(hasil);
                } else if (rbKurang.isChecked()) {
                    hasil = num1 - num2;
                    hishasil = String.valueOf(num1) + " - " + String.valueOf(num2) + " = " + String.valueOf(hasil);
                } else if (rbKali.isChecked()) {
                    hasil = num1 * num2;
                    hishasil = String.valueOf(num1) + " * " + String.valueOf(num2) + " = " + String.valueOf(hasil);
                } else if (rbBagi.isChecked()) {
                    hasil = num1 / num2;
                    hishasil = String.valueOf(num1) + " / " + String.valueOf(num2) + " = " + String.valueOf(hasil);
                }
                list_history.add(hishasil);
                Collections.reverse(list_history);
                editor.putString("history", String.valueOf(list_history));
                editor.apply();

                txtHasil.setText(String.valueOf(hasil));

                Context context;
                RecyclerView recyclerView;
                RecyclerView.Adapter recyclerViewAdapter;
                RecyclerView.LayoutManager recylerViewLayoutManager;
                String hasil_history = sharedPreferences.getString("history", null);
                hasil_history = hasil_history.substring(1,hasil_history.length()-1);
                String[] list_history = hasil_history.split(",");

                context = getApplicationContext();
                recyclerView = findViewById(R.id.recyclerView);
                recylerViewLayoutManager = new LinearLayoutManager(context);
                recyclerView.setLayoutManager(recylerViewLayoutManager);
                recyclerViewAdapter = new AdapterRecyclerView(context, list_history);
                recyclerView.setAdapter(recyclerViewAdapter);
            }
        });
    }
}